<?php
function uploadImage($file)
{
    if (!$file || $file['error'] !== UPLOAD_ERR_OK) return false;

    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return false;

    $newName = uniqid('img_') . '.' . $ext;
    $destination = __DIR__ . '/../assets/images/' . $newName;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return $newName;
    }

    return false;
}

function formatDateTime($date, $time) {
    return date('d/m/Y H:i', strtotime($date . ' ' . $time));
}

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
