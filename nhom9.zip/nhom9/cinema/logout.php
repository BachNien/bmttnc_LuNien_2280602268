<?php
session_start();
session_destroy();
header("Location: /nhom9/cinema/login.php");
exit;
