CREATE DATABASE IF NOT EXISTS davaxemphim CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE davaxemphim;

-- Xoá bảng nếu đã tồn tại
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS showtimes;
DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS users;

-- Tạo bảng users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user'
);

-- Tạo bảng movies
CREATE TABLE movies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    duration INT NOT NULL,
    description TEXT,
    image VARCHAR(255)
);

-- Tạo bảng showtimes
CREATE TABLE showtimes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT NOT NULL,
    show_date DATE NOT NULL,
    show_time TIME NOT NULL,
    room VARCHAR(50),
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
);

-- Tạo bảng bookings
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    showtime_id INT NOT NULL,
    seats VARCHAR(100) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (showtime_id) REFERENCES showtimes(id) ON DELETE CASCADE
);

-- Admin mặc định
INSERT INTO users (name, email, password, role)
VALUES ('Admin', 'admin@gmail.com', '$2y$10$9ZnTT9fu1Pd6T9OTFlF3AesXjZ4yH7wnqfx/1Bp0AJlqpYX/dAwF2', 'admin'); 
-- Mật khẩu: 123456

-- Người dùng thử
INSERT INTO users (name, email, password)
VALUES 
('Nguyễn Văn A', 'a@gmail.com', '$2y$10$w5.CblNLMIxTxZoOMnX30e9NTW0Jvjz3k5sXvAUb88/MfO88pZeX2'), -- 123456
('Trần Thị B', 'b@gmail.com', '$2y$10$w5.CblNLMIxTxZoOMnX30e9NTW0Jvjz3k5sXvAUb88/MfO88pZeX2');

-- Phim mẫu
INSERT INTO movies (title, genre, duration, description, image)
VALUES 
('Avengers: Endgame', 'Hành động', 181, 'Biệt đội Avengers chiến đấu để cứu vũ trụ khỏi Thanos.', 'avengers.jpg'),
('Your Name', 'Lãng mạn', 106, 'Hai thiếu niên hoán đổi cơ thể và cố gắng tìm nhau qua thời gian.', 'placeholder.jpg'),
('Inception', 'Khoa học viễn tưởng', 148, 'Một kẻ đánh cắp giấc mơ dẫn đội xâm nhập vào tiềm thức.', 'placeholder.jpg'),
('Interstellar', 'Khoa học, không gian', 169, 'Chuyến du hành tìm nơi sinh sống mới cho nhân loại.', 'placeholder.jpg');

-- Suất chiếu mẫu
INSERT INTO showtimes (movie_id, show_date, show_time, room)
VALUES
(1, '2025-06-22', '18:30:00', 'Phòng A'),
(1, '2025-06-23', '20:00:00', 'Phòng B'),
(2, '2025-06-22', '17:00:00', 'Phòng C'),
(3, '2025-06-24', '19:15:00', 'Phòng A'),
(4, '2025-06-25', '16:00:00', 'Phòng B');

-- Đặt vé mẫu
INSERT INTO bookings (user_id, showtime_id, seats)
VALUES
(1, 1, 'A1,A2,A3'),
(2, 2, 'B5,B6'),
(1, 3, 'C1,C2'),
(2, 4, 'D1'),
(1, 5, 'E1,E2,E3');
"""