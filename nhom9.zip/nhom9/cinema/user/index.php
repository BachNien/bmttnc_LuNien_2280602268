<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkLogin();

// Sửa chỗ này: dùng id thay vì created_at
$stmt = $pdo->query("SELECT * FROM movies ORDER BY id DESC");
$movies = $stmt->fetchAll();
?>

<?php include 'header.php'; ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background-color: #121212;
        color: #f1f1f1;
        font-family: 'Segoe UI', sans-serif;
    }

    .section-title {
        font-weight: 700;
        font-size: 1.8rem;
        text-align: center;
        margin-bottom: 30px;
        color: #ffffff;
    }

    .movie-card {
        background-color: #1e1e1e;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 20px rgba(255, 255, 255, 0.04);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        height: 100%;
    }

    .movie-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 30px rgba(255, 255, 255, 0.06);
    }

    .movie-card img {
        width: 100%;
        height: 240px;
        object-fit: cover;
        display: block;
    }

    .movie-card .card-body {
        padding: 15px;
    }

    .movie-card .card-title {
        font-size: 1rem;
        font-weight: 600;
        color: #fff;
        margin-bottom: 8px;
    }

    .movie-card .card-text {
        font-size: 0.9rem;
        color: #aaa;
        margin-bottom: 12px;
    }

    .btn-detail {
        background-color: #0d6efd;
        border: none;
        font-weight: 500;
        font-size: 0.9rem;
        color: white;
        width: 100%;
        padding: 8px 0;
        border-radius: 6px;
        transition: background-color 0.3s ease;
    }

    .btn-detail:hover {
        background-color: #0b5ed7;
    }

    @media (max-width: 767px) {
        .movie-card img {
            height: 180px;
        }
    }
</style>

<div class="container mt-4 mb-4">
    <h2 class="section-title">Danh sách phim đang chiếu</h2>
    <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-5 g-3">
        <?php foreach ($movies as $movie): ?>
            <div class="col">
                <div class="card movie-card">
                    <img src="../assets/images/<?= htmlspecialchars($movie['image']) ?>" alt="Poster phim">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($movie['title']) ?></h5>
                        <p class="card-text">Thể loại: <?= htmlspecialchars($movie['genre']) ?></p>
                        <a href="movie.php?id=<?= $movie['id'] ?>" class="btn btn-detail">Xem chi tiết</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include 'footer.php'; ?>
