<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkLogin();

$id = $_GET['id'] ?? null;

if (!$id || !is_numeric($id)) {
    header("Location: my_tickets.php");
    exit;
}

// Kiểm tra vé có tồn tại và thuộc về user hiện tại
$stmt = $pdo->prepare("
    SELECT b.*, s.show_date, s.show_time 
    FROM bookings b 
    JOIN showtimes s ON b.showtime_id = s.id
    WHERE b.id = ? AND b.user_id = ?
");
$stmt->execute([$id, $_SESSION['user_id']]);
$ticket = $stmt->fetch();

if (!$ticket) {
    header("Location: my_tickets.php");
    exit;
}

// Kiểm tra suất đã chiếu chưa
$showTime = strtotime($ticket['show_date'] . ' ' . $ticket['show_time']);
if ($showTime <= time()) {
    // Đã chiếu rồi, không huỷ
    $_SESSION['cancel_error'] = "Không thể huỷ vé vì suất chiếu đã diễn ra.";
    header("Location: my_tickets.php");
    exit;
}

// Huỷ vé (xoá bản ghi)
$stmt = $pdo->prepare("DELETE FROM bookings WHERE id = ?");
$stmt->execute([$id]);

$_SESSION['cancel_success'] = "Đã huỷ vé thành công.";
header("Location: my_tickets.php");
exit;
