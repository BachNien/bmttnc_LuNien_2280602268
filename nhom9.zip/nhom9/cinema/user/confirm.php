<?php
require_once '../includes/auth.php';
checkLogin();

if (!isset($_SESSION['last_booking'])) {
    header("Location: index.php");
    exit;
}

$info = $_SESSION['last_booking'];
unset($_SESSION['last_booking']);
?>

<?php include 'header.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
    body {
        background-color: #121212;
        color: #eee;
        font-family: 'Segoe UI', sans-serif;
    }

    .ticket-card {
        background-color: #1e1e1e;
        border: none;
        border-radius: 14px;
        box-shadow: 0 0 25px rgba(255,255,255,0.03);
        padding: 30px;
        max-width: 600px;
        margin: 50px auto;
        text-align: center;
    }

    .ticket-card h3 {
        color: #fff;
        font-weight: 600;
        margin-bottom: 20px;
    }

    .ticket-info {
        text-align: left;
        margin-top: 20px;
    }

    .ticket-info i {
        color: #0d6efd;
        margin-right: 10px;
    }

    .btn-home {
        margin-top: 30px;
        border-radius: 30px;
        padding: 10px 24px;
        font-weight: 500;
        background-color: transparent;
        border: 1px solid #888;
        color: #eee;
        transition: 0.3s;
    }

    .btn-home:hover {
        background-color: #0d6efd;
        color: #fff;
        border-color: #0d6efd;
    }
</style>

<div class="ticket-card">
    <h3><i class="bi bi-check-circle-fill text-success"></i> Đặt vé thành công!</h3>
    <p class="text-muted">Cảm ơn bạn đã sử dụng hệ thống đặt vé 🎬</p>

    <div class="ticket-info mt-4">
        <p><i class="bi bi-film"></i> <strong>Phim:</strong> <?= htmlspecialchars($info['movie_title']) ?></p>
        <p><i class="bi bi-clock-fill"></i> <strong>Suất chiếu:</strong> <?= htmlspecialchars($info['showtime']) ?></p>
        <p><i class="bi bi-grid-3x3-gap-fill"></i> <strong>Ghế:</strong> <?= htmlspecialchars($info['seat']) ?></p>
        <p><i class="bi bi-envelope-fill"></i> Vé đã được gửi đến email: <strong><?= htmlspecialchars($_SESSION['user_email']) ?></strong></p>
    </div>

    <a href="index.php" class="btn btn-home">
        <i class="bi bi-arrow-left-circle"></i> Về trang chủ
    </a>
</div>

<?php include 'footer.php'; ?>
