<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkLogin();

$id = $_GET['id'] ?? null;
if (!$id || !is_numeric($id)) {
    header("Location: not_found.php");
    exit;
}

// Lấy thông tin phim
$stmt = $pdo->prepare("SELECT * FROM movies WHERE id = ?");
$stmt->execute([$id]);
$movie = $stmt->fetch();

if (!$movie) {
    header("Location: not_found.php");
    exit;
}

// Lấy các suất chiếu
$stmt = $pdo->prepare("SELECT * FROM showtimes WHERE movie_id = ? AND show_date >= CURDATE() ORDER BY show_date, show_time");
$stmt->execute([$id]);
$showtimes = $stmt->fetchAll();
?>

<?php include 'header.php'; ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background-color: #121212;
        color: #f1f1f1;
        font-family: 'Segoe UI', sans-serif;
    }

    .movie-poster {
        width: 100%;
        height: auto;
        border-radius: 12px;
        box-shadow: 0 0 15px rgba(255, 255, 255, 0.1);
        object-fit: cover;
        max-height: 540px;
    }

    .movie-title {
        font-size: 2rem;
        font-weight: 600;
        margin-bottom: 10px;
    }

    .movie-info p {
        margin-bottom: 8px;
        color: #ccc;
    }

    .movie-description {
        margin-top: 20px;
        line-height: 1.6;
    }

    .showtime-section {
        margin-top: 40px;
    }

    .list-group-item {
        background-color: #1e1e1e;
        color: #ddd;
        border: 1px solid #333;
    }

    .list-group-item:hover {
        background-color: #2a2a2a;
    }

    .btn-book {
        background-color: #007bff;
        border: none;
        padding: 6px 16px;
        font-weight: 500;
        color: #fff;
    }

    .btn-book:hover {
        background-color: #0056b3;
    }

    .text-danger {
        color: #ff4d4d !important;
    }
</style>

<div class="container mt-4 mb-5">
    <div class="row g-4">
        <div class="col-md-4">
            <img src="../assets/images/<?= htmlspecialchars($movie['image']) ?>" alt="Poster phim" class="movie-poster">
        </div>
        <div class="col-md-8">
            <div class="movie-title"><?= htmlspecialchars($movie['title']) ?></div>
            <div class="movie-info">
                <p><strong>Thể loại:</strong> <?= htmlspecialchars($movie['genre']) ?></p>
                <p><strong>Thời lượng:</strong> <?= $movie['duration'] ?> phút</p>
                <p><strong>Giá vé:</strong> <?= number_format($movie['price'], 0, ',', '.') ?> ₫</p>
            </div>
            <div class="movie-description">
                <?= nl2br(htmlspecialchars($movie['description'])) ?>
            </div>

            <div class="showtime-section">
                <h4 class="mb-3">Suất chiếu khả dụng</h4>
                <?php if (count($showtimes) > 0): ?>
                    <ul class="list-group">
                        <?php foreach ($showtimes as $show): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?= date('d/m/Y', strtotime($show['show_date'])) ?> – <?= substr($show['show_time'], 0, 5) ?> – Phòng: <?= $show['room'] ?>
                                <a href="book.php?showtime_id=<?= $show['id'] ?>" class="btn btn-sm btn-book">Đặt vé</a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="text-danger mt-2">Hiện chưa có suất chiếu.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
