<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
checkLogin();

$errors = [];
$success = false;

$user_id = $_SESSION['user_id'] ?? null;
$showtime_id = $_GET['showtime_id'] ?? null;

if (!$showtime_id || !is_numeric($showtime_id)) {
    header("Location: not_found.php");
    exit;
}

// Lấy thông tin suất chiếu + phim + giá vé
$stmt = $pdo->prepare("SELECT s.*, m.title AS movie_title, m.price FROM showtimes s JOIN movies m ON s.movie_id = m.id WHERE s.id = ?");
$stmt->execute([$showtime_id]);
$showtime = $stmt->fetch();

if (!$showtime) {
    header("Location: not_found.php");
    exit;
}

// Ghế đã đặt
$stmt = $pdo->prepare("SELECT seats FROM bookings WHERE showtime_id = ?");
$stmt->execute([$showtime_id]);
$booked_seats_raw = array_column($stmt->fetchAll(), 'seats');

$booked_seats = [];
foreach ($booked_seats_raw as $item) {
    $seats_array = array_map('trim', explode(',', $item));
    $booked_seats = array_merge($booked_seats, $seats_array);
}

// Xử lý đặt vé
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $seats = array_map('trim', explode(',', strtoupper($_POST['seat'] ?? '')));
    $seats = array_filter($seats);

    if (empty($seats)) {
        $errors[] = 'Vui lòng chọn ít nhất một ghế.';
    } elseif (array_intersect($seats, $booked_seats)) {
        $errors[] = 'Một hoặc nhiều ghế đã được đặt.';
    } else {
        $seat_string = implode(',', $seats);
        $statement = $pdo->prepare("INSERT INTO bookings (user_id, showtime_id, seats) VALUES (?, ?, ?)");
        $statement->execute([$user_id, $showtime_id, $seat_string]);

        $_SESSION['last_booking'] = [
            'movie_title' => $showtime['movie_title'],
            'showtime' => $showtime['show_date'] . ' ' . $showtime['show_time'],
            'seat' => $seat_string
        ];

        require_once '../mail/send.php';
        sendBookingMail($_SESSION['user_email'], $showtime['movie_title'], $showtime['show_date'], $showtime['show_time'], $seat_string);

        header("Location: confirm.php");
        exit;
    }
}
?>

<?php include 'header.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    .seat {
        width: 40px;
        height: 40px;
        background-color: #ccc;
        margin: 5px;
        text-align: center;
        line-height: 40px;
        border-radius: 6px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    .seat.selected {
        background-color: #28a745;
        color: white;
    }
    .seat.booked {
        background-color: #dc3545;
        color: white;
        cursor: not-allowed;
    }
    .screen {
        height: 40px;
        background-color: #999;
        margin: 20px auto;
        width: 70%;
        text-align: center;
        line-height: 40px;
        border-radius: 4px;
        font-weight: bold;
    }
</style>
<div class="container mt-5">
    <h2>Đặt vé - <?= htmlspecialchars($showtime['movie_title']) ?></h2>
    <p><strong>Suất chiếu:</strong> <?= formatDateTime($showtime['show_date'], $showtime['show_time']) ?> - Phòng <?= $showtime['room'] ?></p>

    <?php if ($errors): ?>
        <div class="alert alert-danger"><?= implode('<br>', $errors) ?></div>
    <?php endif; ?>

    <form method="post">
        <input type="hidden" name="seat" id="seat-input" required>
        <div class="mb-3">
            <label>Chọn ghế:</label>
            <div class="screen">Màn Hình</div>
            <div class="d-flex flex-wrap justify-content-center" style="max-width: 500px; margin: auto;">
                <?php
                $rows = ['A','B','C','D','E'];
                for ($r = 0; $r < count($rows); $r++) {
                    for ($i = 1; $i <= 8; $i++) {
                        $seatCode = $rows[$r] . $i;
                        $isBooked = in_array($seatCode, $booked_seats);
                        echo '<div class="seat ' . ($isBooked ? 'booked' : '') . '" data-seat="' . $seatCode . '">' . $seatCode . '</div>';
                    }
                }
                ?>
            </div>
        </div>
        <div class="mt-3">
            <strong>Ghế đã chọn:</strong> <span id="selected-seats">Chưa chọn</span><br>
            <strong>Tổng tiền:</strong> <span id="total-price">0 ₫</span>
        </div>
        <button class="btn btn-success mt-3">Xác nhận đặt vé</button>
    </form>
</div>

<script>
    const ticketPrice = <?= (int)$showtime['price'] ?>;
    const seatDivs = document.querySelectorAll('.seat:not(.booked)');
    const seatInput = document.getElementById('seat-input');
    const selectedDisplay = document.getElementById('selected-seats');
    const priceDisplay = document.getElementById('total-price');
    const selectedSeats = new Set();

    seatDivs.forEach(seat => {
        seat.addEventListener('click', () => {
            const seatCode = seat.dataset.seat;
            if (seat.classList.contains('selected')) {
                seat.classList.remove('selected');
                selectedSeats.delete(seatCode);
            } else {
                seat.classList.add('selected');
                selectedSeats.add(seatCode);
            }

            const selectedArray = Array.from(selectedSeats);
            seatInput.value = selectedArray.join(',');
            selectedDisplay.textContent = seatInput.value || 'Chưa chọn';
            priceDisplay.textContent = (selectedArray.length * ticketPrice).toLocaleString('vi-VN') + ' ₫';
        });
    });
</script>
<?php include 'footer.php'; ?>
