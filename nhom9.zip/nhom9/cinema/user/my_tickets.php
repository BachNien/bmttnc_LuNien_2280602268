<?php
require_once '../includes/functions.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkLogin();

// Lấy vé của user hiện tại
$stmt = $pdo->prepare("
    SELECT b.id, b.seats, b.created_at,
           s.show_date, s.show_time, s.room,
           m.title AS movie_title, m.image
    FROM bookings b
    JOIN showtimes s ON b.showtime_id = s.id
    JOIN movies m ON s.movie_id = m.id
    WHERE b.user_id = ?
    ORDER BY s.show_date DESC, s.show_time DESC
");
$stmt->execute([$_SESSION['user_id']]);
$tickets = $stmt->fetchAll();
?>

<?php include 'header.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background-color: #121212;
        color: #f1f1f1;
        font-family: 'Segoe UI', sans-serif;
    }
    .container {
        margin-top: 40px;
    }
    .ticket-card {
        background-color: #1e1e1e;
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 0 15px rgba(255,255,255,0.05);
        display: flex;
        align-items: center;
    }
    .ticket-card img {
        width: 100px;
        height: 140px;
        object-fit: cover;
        border-radius: 8px;
        margin-right: 20px;
    }
    .ticket-info {
        flex-grow: 1;
    }
    .ticket-info h5 {
        margin-bottom: 10px;
        font-weight: 600;
        color: #fff;
    }
    .ticket-info p {
        margin: 2px 0;
        color: #ccc;
        font-size: 0.95rem;
    }
    .ticket-actions {
        text-align: right;
    }
    .btn-cancel {
        font-size: 0.9rem;
    }
</style>

<div class="container">
    <h2 class="mb-4">🎟 Vé đã đặt</h2>

    <?php if (!empty($_SESSION['cancel_success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['cancel_success'] ?></div>
        <?php unset($_SESSION['cancel_success']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['cancel_error'])): ?>
        <div class="alert alert-danger"><?= $_SESSION['cancel_error'] ?></div>
        <?php unset($_SESSION['cancel_error']); ?>
    <?php endif; ?>

    <?php if (count($tickets) === 0): ?>
        <p>Bạn chưa đặt vé nào.</p>
    <?php else: ?>
        <?php foreach ($tickets as $t): ?>
            <div class="ticket-card">
                <img src="../assets/images/<?= htmlspecialchars($t['image']) ?>" alt="Poster">
                <div class="ticket-info">
                    <h5><?= htmlspecialchars($t['movie_title']) ?></h5>
                    <p>📅 Suất chiếu: <?= formatDateTime($t['show_date'], $t['show_time']) ?></p>
                    <p>🏢 Phòng: <?= htmlspecialchars($t['room']) ?></p>
                    <p>💺 Ghế: <?= htmlspecialchars($t['seats']) ?></p>
                    <p>🕒 Đặt lúc: <?= date('d/m/Y H:i', strtotime($t['created_at'])) ?></p>
                </div>
                <div class="ticket-actions">
                    <?php
                        $show_datetime = strtotime($t['show_date'] . ' ' . $t['show_time']);
                        $now = time();
                        if ($show_datetime > $now):
                    ?>
                        <a href="cancel.php?id=<?= $t['id'] ?>" class="btn btn-outline-danger btn-cancel" onclick="return confirm('Bạn chắc chắn muốn huỷ vé này?')">Huỷ vé</a>
                    <?php else: ?>
                        <span class="text-muted">Đã chiếu</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif ?>
</div>
<?php include 'footer.php'; ?>
