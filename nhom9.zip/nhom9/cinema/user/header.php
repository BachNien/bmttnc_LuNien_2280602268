<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đặt vé xem phim</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar-brand {
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .nav-link {
            font-weight: 500;
            margin-left: 10px;
            transition: 0.2s ease;
        }

        .nav-link:hover {
            color: #ffc107 !important;
        }

        .navbar {
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">Rạp Phim</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <?php if (isset($_SESSION['user_id'])): ?>
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <li class="nav-item"><a class="nav-link" href="../admin/dashboard.php">Quản trị</a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.php">Đăng xuất</a></li>
            <?php else: ?>
                <li class="nav-item"><a class="nav-link" href="my_tickets.php">Vé của tôi</a></li>
                <li class="nav-item"><a class="nav-link" href="profile.php"><?= htmlspecialchars($_SESSION['user_name']) ?></a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.php">Đăng xuất</a></li>
            <?php endif; ?>
        <?php else: ?>
            <li class="nav-item"><a class="nav-link" href="../login.php">Đăng nhập</a></li>
            <li class="nav-item"><a class="nav-link" href="../register.php">Đăng ký</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
