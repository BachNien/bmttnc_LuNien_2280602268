<?php include 'header.php'; ?>
<div class="container mt-5 text-center">
    <h1>❌ Không tìm thấy dữ liệu</h1>
    <p>Trang bạn truy cập không tồn tại hoặc nội dung đã bị xoá.</p>
    <a href="index.php" class="btn btn-primary mt-3">🏠 Về trang chủ</a>
</div>
<?php include 'footer.php'; ?>
