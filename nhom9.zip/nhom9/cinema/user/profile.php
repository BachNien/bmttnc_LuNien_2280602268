<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkLogin();

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
?>

<?php include 'header.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<style>
    body {
        background-color: #121212;
        color: #f1f1f1;
        font-family: 'Segoe UI', sans-serif;
    }

    .profile-card {
        background-color: #1e1e1e;
        border-radius: 12px;
        padding: 30px;
        box-shadow: 0 0 15px rgba(255,255,255,0.05);
        max-width: 600px;
        margin: 50px auto;
    }

    .profile-card h2 {
        font-weight: 600;
        margin-bottom: 25px;
        text-align: center;
        color: #ffffff;
    }

    .profile-card .info-item {
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        font-size: 1rem;
    }

    .profile-card .info-item i {
        margin-right: 10px;
        font-size: 1.2rem;
        color: #0d6efd;
        width: 30px;
    }

    .back-btn {
        display: block;
        text-align: center;
        margin-top: 30px;
    }

    .back-btn .btn {
        border-radius: 30px;
        font-weight: 500;
        padding: 8px 20px;
    }
</style>

<div class="profile-card">
    <h2><i class="bi bi-person-circle"></i> Thông tin cá nhân</h2>

    <div class="info-item">
        <i class="bi bi-person-fill"></i>
        <strong>Họ và tên:</strong>&nbsp; <?= htmlspecialchars($user['name']) ?>
    </div>

    <div class="info-item">
        <i class="bi bi-envelope-fill"></i>
        <strong>Email:</strong>&nbsp; <?= htmlspecialchars($user['email']) ?>
    </div>

    <div class="info-item">
        <i class="bi bi-shield-lock-fill"></i>
        <strong>Quyền:</strong>&nbsp; <?= $user['role'] === 'admin' ? 'Quản trị viên' : 'Người dùng' ?>
    </div>

    <div class="back-btn">
        <a href="index.php" class="btn btn-outline-light">
            <i class="bi bi-arrow-left-circle"></i> Quay về trang chủ
        </a>
    </div>
</div>

<?php include 'footer.php'; ?>
