<?php
session_start();

if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: user/index.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>🎬 Web Đặt Vé Xem Phim</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap & Font -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: #0e0e0e url('assets/images/cinema-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            overflow: hidden;
        }

        .overlay {
            background: rgba(0, 0, 0, 0.7);
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .welcome-box {
            background: rgba(255, 255, 255, 0.05);
            padding: 60px 40px;
            border-radius: 20px;
            text-align: center;
            color: #f1f1f1;
            backdrop-filter: blur(14px);
            box-shadow: 0 0 40px rgba(255, 255, 255, 0.05);
            max-width: 600px;
            width: 100%;
            transition: all 0.3s ease;
        }

        .welcome-box:hover {
            box-shadow: 0 0 60px rgba(255, 255, 255, 0.08);
        }

        .welcome-box h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 15px;
            letter-spacing: 1px;
        }

        .welcome-box p {
            font-size: 1.1rem;
            margin-bottom: 35px;
            color: #ccc;
        }

        .btn-custom {
            font-size: 1.1rem;
            padding: 12px 30px;
            border-radius: 30px;
            transition: 0.3s ease;
            font-weight: 600;
        }

        .btn-login {
            background-color: #ffffff;
            color: #000;
            border: none;
        }

        .btn-login:hover {
            background-color: #e6e6e6;
        }

        .btn-register {
            background-color: transparent;
            color: #ffffff;
            border: 2px solid #fff;
        }

        .btn-register:hover {
            background-color: #ffffff;
            color: #000;
        }

        @media (max-width: 576px) {
            .welcome-box {
                padding: 40px 20px;
            }

            .welcome-box h1 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="overlay">
        <div class="welcome-box">
            <h1>🎬 Chào mừng đến với rạp phim trực tuyến</h1>
            <p>Đặt vé nhanh – giao diện mượt – trải nghiệm tuyệt vời.</p>
            <a href="login.php" class="btn btn-custom btn-login m-2">🚪 Đăng nhập</a>
            <a href="register.php" class="btn btn-custom btn-register m-2">📝 Đăng ký</a>
        </div>
    </div>
</body>
</html>
