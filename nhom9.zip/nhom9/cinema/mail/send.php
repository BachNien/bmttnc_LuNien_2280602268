<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';
require_once 'PHPMailer/src/Exception.php';

function sendBookingMail($toEmail, $movieTitle, $date, $time, $seat) {
    $mail = new PHPMailer(true);

    try {
        // Cấu hình server SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'yourgmail@gmail.com';        // 🔁 Đổi email gửi
        $mail->Password = 'your_app_password';          // 🔁 Đổi password (app password Gmail)
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Người gửi
        $mail->setFrom('yourgmail@gmail.com', 'Rạp Chiếu Phim');
        $mail->addAddress($toEmail);

        // Nội dung
        $mail->isHTML(true);
        $mail->Subject = '🎫 Xác nhận đặt vé thành công';
        $mail->Body = "
            <h3>Cảm ơn bạn đã đặt vé!</h3>
            <p><strong>Phim:</strong> $movieTitle</p>
            <p><strong>Suất chiếu:</strong> $date lúc $time</p>
            <p><strong>Ghế:</strong> $seat</p>
            <p>Chúc bạn xem phim vui vẻ!</p>
        ";

        $mail->send();
        // echo 'Mail đã gửi.';
    } catch (Exception $e) {
        error_log("Gửi mail thất bại: {$mail->ErrorInfo}");
    }
}
