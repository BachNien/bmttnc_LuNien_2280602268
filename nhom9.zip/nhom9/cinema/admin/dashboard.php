<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkAdmin();

$userName = $_SESSION['user_name'] ?? 'Admin';

// Lấy danh sách phim (sắp xếp theo id mới nhất)
$movies = $pdo->query("SELECT id, title, image FROM movies ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>🎬 Admin Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #121212;
      color: #f0f0f0;
      font-family: 'Segoe UI', sans-serif;
    }
    .sidebar {
      width: 240px;
      height: 100vh;
      position: fixed;
      background-color: #0d1117;
      padding: 20px;
    }
    .sidebar a {
      display: block;
      color: #ccc;
      text-decoration: none;
      margin: 15px 0;
      font-size: 16px;
    }
    .sidebar a:hover {
      color: #fff;
    }
    .content {
      margin-left: 260px;
      padding: 40px 20px;
    }
    .card {
      background-color: #1e1e1e;
      border: none;
      border-radius: 12px;
      overflow: hidden;
      transition: transform 0.2s ease-in-out;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .card img {
      height: 260px;
      object-fit: cover;
      width: 100%;
    }
    footer {
      margin-top: 60px;
      padding: 20px;
      background-color: #0d1117;
      color: #ccc;
      text-align: center;
      border-top: 1px solid #2c2c2c;
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h4 class="text-white mb-4"><i class="fas fa-clapperboard"></i> Admin Panel</h4>
  <a href="dashboard.php"><i class="fas fa-chart-bar me-2"></i> Thống kê</a>
  <a href="users.php"><i class="fas fa-users me-2"></i> Người dùng</a>
  <a href="movies.php"><i class="fas fa-film me-2"></i> Quản lý phim</a>
  <a href="showtimes.php"><i class="far fa-clock me-2"></i> Suất chiếu</a>
  <a href="bookings.php"><i class="fas fa-ticket-alt me-2"></i> Vé đã đặt</a>
  <hr class="text-secondary" />
  <a href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Đăng xuất</a>
</div>

<!-- Main content -->
<div class="content">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="fas fa-film me-2"></i>Danh sách phim đang chiếu</h2>
    <div class="text-end">
      <i class="fas fa-user"></i> <?= htmlspecialchars($userName) ?>
    </div>
  </div>

  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
    <?php foreach ($movies as $movie): ?>
      <div class="col">
        <div class="card h-100 text-white">
          <img src="../assets/images/<?= htmlspecialchars($movie['image']) ?>" 
               alt="<?= htmlspecialchars($movie['title']) ?>" 
               class="card-img-top">
          <div class="card-body text-center">
            <h5 class="card-title"><?= htmlspecialchars($movie['title']) ?></h5>
          </div>
          <div class="card-footer bg-transparent border-top-0 text-center">
            <a href="movie_edit.php?id=<?= $movie['id'] ?>" class="btn btn-outline-light btn-sm">
              <i class="fas fa-edit"></i> Sửa
            </a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <footer class="mt-5">
    © <?= date('Y') ?> Rạp phim | Hệ thống quản trị hiện đại
  </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
