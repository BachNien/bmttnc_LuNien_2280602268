<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
checkAdmin();

$id = $_GET['id'] ?? null;
if (!$id || !is_numeric($id)) {
    header('Location: movies.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM movies WHERE id = ?");
$stmt->execute([$id]);
$movie = $stmt->fetch();
if (!$movie) {
    header('Location: movies.php');
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $genre = trim($_POST['genre']);
    $duration = trim($_POST['duration']);
    $description = trim($_POST['description']);
    $price = trim($_POST['price']);

    if (!$title || !$genre || !$duration || !$description || !$price) {
        $errors[] = "Vui lòng nhập đầy đủ thông tin.";
    }

    if (!is_numeric($price) || $price < 0) {
        $errors[] = "Giá vé phải là số hợp lệ.";
    }

    $newImage = $movie['image'];
    if (!empty($_FILES['image']['name'])) {
        $uploaded = uploadImage($_FILES['image']);
        if ($uploaded) {
            $newImage = $uploaded;
            @unlink('../assets/images/' . $movie['image']);
        } else {
            $errors[] = "Tải ảnh thất bại. Vui lòng chọn đúng định dạng.";
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("UPDATE movies SET title = ?, genre = ?, duration = ?, description = ?, image = ?, price = ? WHERE id = ?");
        $stmt->execute([$title, $genre, $duration, $description, $newImage, $price, $id]);
        $success = true;
        header("refresh:1.5;url=dashboard.php");
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Sửa phim</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f9f9f9;
      font-family: 'Segoe UI', sans-serif;
    }
    .container {
      max-width: 700px;
      background: white;
      border-radius: 12px;
      padding: 30px;
      margin-top: 40px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    }
    img.preview {
      border-radius: 12px;
      margin-bottom: 10px;
      max-width: 150px;
    }
  </style>
</head>
<body>
<div class="container">
    <h3 class="mb-4 text-primary">🎬 Chỉnh sửa thông tin phim</h3>

    <?php if ($errors): ?>
        <div class="alert alert-danger"><?= implode('<br>', $errors) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success">✅ Cập nhật thành công! Đang chuyển hướng...</div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Tiêu đề phim</label>
            <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($movie['title']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Thể loại</label>
            <input type="text" name="genre" class="form-control" value="<?= htmlspecialchars($movie['genre']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Thời lượng (phút)</label>
            <input type="number" name="duration" class="form-control" value="<?= htmlspecialchars($movie['duration']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Giá vé (VNĐ)</label>
            <input type="number" name="price" class="form-control" step="1000" min="0" value="<?= htmlspecialchars($movie['price']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Mô tả</label>
            <textarea name="description" class="form-control" rows="4" required><?= htmlspecialchars($movie['description']) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Ảnh poster hiện tại:</label><br>
            <img src="../assets/images/<?= htmlspecialchars($movie['image']) ?>" class="preview"><br>
            <label class="form-label mt-2">Chọn ảnh mới (nếu muốn):</label>
            <input type="file" name="image" class="form-control" accept="image/*">
        </div>

        <button type="submit" class="btn btn-success">Cập nhật</button>
        <a href="dashboard.php" class="btn btn-secondary ms-2">Quay lại</a>
    </form>
</div>
</body>
</html>
