<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
checkAdmin();

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $genre = trim($_POST['genre']);
    $duration = trim($_POST['duration']);
    $description = trim($_POST['description']);
    $price = trim($_POST['price']);

    // Kiểm tra hợp lệ
    if (!$title || !$genre || !$duration || !$description || !$price) {
        $errors[] = "Vui lòng nhập đầy đủ thông tin.";
    }

    if (!is_numeric($price) || $price < 0) {
        $errors[] = "Giá tiền phải là số hợp lệ.";
    }

    // Upload ảnh
    $image = uploadImage($_FILES['image'] ?? null);
    if ($image === false) {
        $errors[] = "Ảnh không hợp lệ hoặc không thể tải lên.";
    }

    // Lưu vào DB
    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO movies (title, genre, duration, description, image, price) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $genre, $duration, $description, $image, $price]);
        $success = true;
    }
}
?>

<?php include '../user/header.php'; ?>
<div class="container mt-4">
    <h2>➕ Thêm phim mới</h2>

    <?php if ($errors): ?>
        <div class="alert alert-danger"><?= implode('<br>', $errors) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success">✅ Đã thêm phim thành công.</div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" style="max-width: 600px;">
        <div class="mb-3">
            <label>Tiêu đề phim:</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Thể loại:</label>
            <input type="text" name="genre" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Thời lượng (phút):</label>
            <input type="number" name="duration" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Giá vé (VNĐ):</label>
            <input type="number" name="price" class="form-control" step="1000" min="0" required>
        </div>
        <div class="mb-3">
            <label>Mô tả:</label>
            <textarea name="description" class="form-control" rows="4" required></textarea>
        </div>
        <div class="mb-3">
            <label>Ảnh poster:</label>
            <input type="file" name="image" class="form-control" accept="image/*" required>
        </div>
        <button class="btn btn-primary">Lưu phim</button>
    </form>
</div>
<?php include '../user/footer.php'; ?>
