<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkAdmin();

$stmt = $pdo->query("SELECT * FROM movies ORDER BY id DESC");
$movies = $stmt->fetchAll();
?>

<?php include '../user/header.php'; ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<style>
    .table td,
    .table th {
        vertical-align: middle;
    }

    .img-thumbnail {
        max-height: 100px;
        object-fit: cover;
        border: none;
        border-radius: 10px;
    }

    .btn-dark-action {
        background-color: #2c2c2c;
        border: none;
        color: #fff;
    }

    .btn-dark-action:hover {
        background-color: #444;
        color: #fff;
    }

    .btn-action i {
        font-size: 1rem;
    }

    h2 {
        color: #333;
        font-weight: 600;
        margin-bottom: 20px;
    }
</style>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Quản lý phim</h2>
        <a href="dashboard.php" class="btn btn-outline-dark btn-sm">
            <i class="bi bi-arrow-left-circle"></i> Quay lại Trang Chủ
        </a>
    </div>

    <a href="movie_add.php" class="btn btn-dark-action mb-3">
        <i class="bi bi-plus-circle"></i> Thêm phim
    </a>

    <?php if (count($movies) === 0): ?>
        <div class="alert alert-info">Chưa có phim nào.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark text-center">
                    <tr>
                        <th>Poster</th>
                        <th>Tiêu đề</th>
                        <th>Thể loại</th>
                        <th>Thời lượng</th>
                        <th>Giá vé (VNĐ)</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($movies as $movie): ?>
                        <tr class="text-center">
                            <td style="width: 100px">
                                <img src="../assets/images/<?= htmlspecialchars($movie['image']) ?>" class="img-thumbnail" alt="poster">
                            </td>
                            <td><?= htmlspecialchars($movie['title']) ?></td>
                            <td><?= htmlspecialchars($movie['genre']) ?></td>
                            <td><?= htmlspecialchars($movie['duration']) ?> phút</td>
                            <td><?= number_format($movie['price'], 0, ',', '.') ?> ₫</td>
                            <td>
                                <a href="movie_edit.php?id=<?= $movie['id'] ?>" class="btn btn-sm btn-warning btn-action">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <a href="movie_delete.php?id=<?= $movie['id'] ?>" class="btn btn-sm btn-danger btn-action" onclick="return confirm('Bạn có chắc muốn xoá phim này?')">
                                    <i class="bi bi-trash3"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php include '../user/footer.php'; ?>
