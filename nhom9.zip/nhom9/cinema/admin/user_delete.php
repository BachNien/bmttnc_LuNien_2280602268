<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkAdmin();

$id = $_GET['id'] ?? null;
if ($id && is_numeric($id)) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'user'");
    $stmt->execute([$id]);
}
header("Location: users.php");
exit;
