<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkAdmin();

$id = $_GET['id'] ?? null;
if (!$id || !is_numeric($id)) {
    header("Location: movies.php");
    exit;
}

// Kiểm tra phim tồn tại
$stmt = $pdo->prepare("SELECT * FROM movies WHERE id = ?");
$stmt->execute([$id]);
$movie = $stmt->fetch();

if (!$movie) {
    header("Location: movies.php");
    exit;
}

// Xoá ảnh
$imagePath = '../assets/images/' . $movie['image'];
if (file_exists($imagePath)) {
    @unlink($imagePath);
}

// Xoá phim
$stmt = $pdo->prepare("DELETE FROM movies WHERE id = ?");
$stmt->execute([$id]);

header("Location: movies.php");
exit;
