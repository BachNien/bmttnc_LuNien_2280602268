<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkAdmin();

$movie_id = $_GET['id'] ?? null;
if (!$movie_id || !is_numeric($movie_id)) {
    header("Location: showtimes.php");
    exit;
}

// Lấy thông tin phim
$stmt = $pdo->prepare("SELECT * FROM movies WHERE id = ?");
$stmt->execute([$movie_id]);
$movie = $stmt->fetch();
if (!$movie) {
    header("Location: showtimes.php");
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $show_date = $_POST['show_date'] ?? '';
    $show_time = $_POST['show_time'] ?? '';
    $room = trim($_POST['room'] ?? '');

    if (!$show_date || !$show_time || !$room) {
        $errors[] = "Vui lòng nhập đầy đủ thông tin.";
    } else {
        // Kiểm tra trùng phòng + ngày + giờ
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM showtimes WHERE show_date = ? AND show_time = ? AND room = ?");
        $stmt->execute([$show_date, $show_time, $room]);
        $conflict = $stmt->fetchColumn();

        if ($conflict > 0) {
            $errors[] = "Phòng này đã có phim chiếu vào thời gian đó. Vui lòng chọn thời gian khác.";
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO showtimes (movie_id, show_date, show_time, room) VALUES (?, ?, ?, ?)");
        $stmt->execute([$movie_id, $show_date, $show_time, $room]);
        $success = true;
    }
}
?>

<?php include '../user/header.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background-color: #121212;
        color: #f1f1f1;
        font-family: 'Segoe UI', sans-serif;
    }

    .form-container {
        background: #1e1e1e;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 0 15px rgba(255, 255, 255, 0.05);
        max-width: 600px;
        margin: 50px auto;
    }

    .form-container h2 {
        margin-bottom: 25px;
        font-weight: 600;
    }

    label {
        font-weight: 500;
    }

    .form-control {
        background-color: #2a2a2a;
        border: 1px solid #444;
        color: #fff;
    }

    .form-control:focus {
        background-color: #333;
        color: #fff;
        border-color: #555;
        box-shadow: none;
    }

    .btn-primary {
        background-color: #007bff;
        border: none;
        font-weight: 500;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }

    .btn-secondary {
        background-color: #6c757d;
        border: none;
    }

    .btn-secondary:hover {
        background-color: #5a6268;
    }
</style>

<div class="form-container">
    <h2>Thêm Suất Chiếu cho: <strong><?= htmlspecialchars($movie['title']) ?></strong></h2>

    <?php if ($errors): ?>
        <div class="alert alert-danger"><?= implode('<br>', $errors) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success">Suất chiếu đã được thêm thành công.</div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label for="show_date">Ngày chiếu:</label>
            <input type="date" name="show_date" id="show_date" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="show_time">Giờ chiếu:</label>
            <input type="time" name="show_time" id="show_time" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="room">Phòng chiếu:</label>
            <input type="text" name="room" id="room" class="form-control" required placeholder="VD: A, B, 1, 2">
        </div>
        <button class="btn btn-primary">Lưu suất chiếu</button>
        <a href="showtimes.php" class="btn btn-secondary ms-2">Quay lại</a>
    </form>
</div>

<?php include '../user/footer.php'; ?>
