<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkAdmin();

$stmt = $pdo->query("SELECT * FROM movies ORDER BY id DESC");
$movies = $stmt->fetchAll();
?>

<?php include '../user/header.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background-color: #121212;
        color: #f1f1f1;
        font-family: 'Segoe UI', sans-serif;
    }

    .table-container {
        background-color: #1e1e1e;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 0 15px rgba(255, 255, 255, 0.05);
        margin-top: 40px;
    }

    .table th, .table td {
        vertical-align: middle;
        color: #ddd;
        border-color: #444;
    }

    .btn-primary {
        background-color: #007bff;
        border: none;
        font-weight: 500;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }

    .section-title {
        font-size: 1.8rem;
        font-weight: 600;
        margin-bottom: 25px;
        text-align: center;
        color: #ffffff;
    }

    .btn-back {
        margin-bottom: 20px;
    }
</style>

<div class="container table-container">
    <a href="dashboard.php" class="btn btn-outline-light btn-sm btn-back">
        ← Quay về Trang Chủ
    </a>

    <h2 class="section-title">Quản lý suất chiếu theo phim</h2>

    <?php if (count($movies) === 0): ?>
        <p>Chưa có phim nào để tạo suất chiếu.</p>
    <?php else: ?>
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Poster</th>
                    <th>Tiêu đề</th>
                    <th>Thể loại</th>
                    <th>Thời lượng</th>
                    <th>Suất chiếu</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($movies as $movie): ?>
                    <?php
                        $stmt = $pdo->prepare("SELECT show_date, show_time, room FROM showtimes WHERE movie_id = ? ORDER BY show_date, show_time");
                        $stmt->execute([$movie['id']]);
                        $showtimes = $stmt->fetchAll();
                    ?>
                    <tr>
                        <td style="width:100px">
                            <img src="../assets/images/<?= htmlspecialchars($movie['image']) ?>" class="img-thumbnail" style="width:100%">
                        </td>
                        <td><?= htmlspecialchars($movie['title']) ?></td>
                        <td><?= htmlspecialchars($movie['genre']) ?></td>
                        <td><?= htmlspecialchars($movie['duration']) ?> phút</td>
                        <td>
                            <?php if (count($showtimes) > 0): ?>
                                <ul class="list-unstyled mb-0">
                                    <?php foreach ($showtimes as $s): ?>
                                        <li><?= date('d/m/Y', strtotime($s['show_date'])) ?> - <?= substr($s['show_time'], 0, 5) ?> - Phòng <?= htmlspecialchars($s['room']) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <span class="text-muted">Chưa có</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="showtime_add.php?id=<?= $movie['id'] ?>" class="btn btn-sm btn-primary">Thêm suất chiếu</a>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php include '../user/footer.php'; ?>
