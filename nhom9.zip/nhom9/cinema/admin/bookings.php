<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
checkAdmin();

// Lấy danh sách vé đã đặt kèm thông tin phim + giá vé
$sql = "SELECT b.*, 
               u.name AS user_name, u.email, 
               m.title AS movie_title, m.price, 
               s.show_date, s.show_time, s.room
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN showtimes s ON b.showtime_id = s.id
        JOIN movies m ON s.movie_id = m.id
        ORDER BY b.id DESC";

$stmt = $pdo->query($sql);
$bookings = $stmt->fetchAll();
?>

<?php include '../user/header.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
    body {
        background-color: #121212;
        color: #f1f1f1;
        font-family: 'Segoe UI', sans-serif;
    }

    .container {
        background: #1e1e1e;
        padding: 30px;
        border-radius: 12px;
        margin-top: 50px;
        box-shadow: 0 0 20px rgba(255, 255, 255, 0.05);
    }

    h2 {
        font-weight: 600;
        margin-bottom: 30px;
        color: #fff;
    }

    .table {
        background-color: #1e1e1e;
        color: #ddd;
    }

    .table thead th {
        background-color: #2a2a2a;
        color: #fff;
        vertical-align: middle;
    }

    .table td, .table th {
        border-color: #3a3a3a;
        padding: 14px;
        vertical-align: middle;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: #262626;
    }

    .table-striped tbody tr:hover {
        background-color: #333;
    }

    .icon-text i {
        color: #0dcaf0;
        margin-right: 6px;
    }

    .btn-back {
        margin-bottom: 20px;
        font-size: 0.95rem;
    }

    .btn-back i {
        vertical-align: middle;
        margin-right: 4px;
    }
</style>

<div class="container">
    <a href="dashboard.php" class="btn btn-outline-light btn-sm btn-back">
        <i class="bi bi-arrow-left-circle-fill"></i> Quay lại Trang Chủ
    </a>

    <h2><i class="bi bi-ticket-perforated-fill"></i> Danh sách vé đã đặt</h2>

    <?php if (count($bookings) === 0): ?>
        <div class="alert alert-info">Chưa có vé nào được đặt.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr class="text-center">
                        <th><i class="bi bi-film"></i> Phim</th>
                        <th><i class="bi bi-clock"></i> Suất chiếu</th>
                        <th><i class="bi bi-door-open"></i> Phòng</th>
                        <th><i class="bi bi-person"></i> Người đặt</th>
                        <th><i class="bi bi-grid-1x2"></i> Ghế</th>
                        <th><i class="bi bi-currency-dollar"></i> Tổng tiền</th>
                        <th><i class="bi bi-calendar-event"></i> Ngày đặt</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $b): ?>
                        <?php
                            $seatCount = count(explode(',', $b['seats']));
                            $totalPrice = $seatCount * (int)$b['price'];
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($b['movie_title']) ?></td>
                            <td><?= formatDateTime($b['show_date'], $b['show_time']) ?></td>
                            <td><?= htmlspecialchars($b['room']) ?></td>
                            <td>
                                <div class="icon-text">
                                    <i class="bi bi-person-bounding-box"></i>
                                    <?= htmlspecialchars($b['user_name']) ?>
                                </div>
                                <small class="text-muted"><i class="bi bi-envelope"></i> <?= htmlspecialchars($b['email']) ?></small>
                            </td>
                            <td><span class="badge bg-info text-dark"><?= htmlspecialchars($b['seats']) ?></span></td>
                            <td><span class="badge bg-warning text-dark"><?= number_format($totalPrice, 0, ',', '.') ?> ₫</span></td>
                            <td><?= date('d/m/Y H:i', strtotime($b['created_at'])) ?></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php include '../user/footer.php'; ?>
