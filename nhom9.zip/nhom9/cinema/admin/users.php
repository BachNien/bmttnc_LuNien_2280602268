<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
checkAdmin();

$users = $pdo->query("SELECT id, name, email, created_at FROM users WHERE role = 'user' ORDER BY created_at DESC")->fetchAll();
?>

<?php include '../user/header.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    .table th, .table td {
        vertical-align: middle;
    }

    .btn-back {
        margin-bottom: 20px;
    }

    .table thead th {
        background-color: #343a40;
        color: #fff;
    }

    .card {
        border-radius: 12px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
    }
</style>

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">Danh sách người dùng</h2>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">← Quay lại Trang Chủ</a>
    </div>

    <?php if (count($users) === 0): ?>
        <div class="alert alert-info text-center">Chưa có người dùng nào.</div>
    <?php else: ?>
        <div class="card">
            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle mb-0">
                    <thead class="text-center">
                        <tr>
                            <th>ID</th>
                            <th>Họ tên</th>
                            <th>Email</th>
                            <th>Ngày tạo</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr class="text-center">
                                <td><?= $u['id'] ?></td>
                                <td><?= htmlspecialchars($u['name']) ?></td>
                                <td><?= htmlspecialchars($u['email']) ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($u['created_at'])) ?></td>
                                <td>
                                    <a href="user_delete.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bạn có chắc chắn muốn xoá người dùng này?')">Xoá</a>
                                </td>
                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif ?>
</div>

<?php include '../user/footer.php'; ?>
