<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $errors[] = 'Vui lòng nhập đầy đủ email và mật khẩu.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['role'] = $user['role'];

            header("Location: " . ($user['role'] === 'admin' ? 'admin/dashboard.php' : 'user/index.php'));
            exit;
        } else {
            $errors[] = 'Sai email hoặc mật khẩu.';
        }
    }
}
?>

<?php include 'user/header.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

<style>
    body {
        background: url('assets/images/movie-collage.jpg') no-repeat center center fixed;
        background-size: cover;
        font-family: 'Inter', sans-serif;
        color: #f1f1f1;
        position: relative;
    }

    body::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        backdrop-filter: blur(4px);
        z-index: 0;
    }

    .login-container {
        position: relative;
        z-index: 1;
        max-width: 450px;
        margin: 100px auto;
        background: rgba(255, 255, 255, 0.05);
        padding: 40px;
        border-radius: 15px;
        backdrop-filter: blur(12px);
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.3);
    }

    .login-container h2 {
        text-align: center;
        margin-bottom: 25px;
        font-weight: 600;
        font-size: 2rem;
        color: #fff;
    }

    .form-label {
        font-weight: 500;
        color: #ddd;
    }

    .form-control {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid #555;
        color: #fff;
    }

    .form-control:focus {
        background-color: rgba(255, 255, 255, 0.15);
        color: #fff;
        border-color: #777;
        box-shadow: none;
    }

    .btn-primary {
        background-color: #0d6efd;
        border: none;
        font-weight: 600;
    }

    .btn-primary:hover {
        background-color: #0b5ed7;
    }

    .alert-danger {
        background-color: rgba(255, 0, 0, 0.1);
        border-color: #ff4d4d;
        color: #ff4d4d;
    }

    .form-footer {
        text-align: center;
        margin-top: 20px;
        color: #bbb;
    }

    a {
        color: #00bfff;
    }

    a:hover {
        color: #fff;
        text-decoration: underline;
    }
</style>

<div class="login-container">
    <h2>Đăng nhập</h2>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <?= implode('<br>', $errors) ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label class="form-label" for="email">Email:</label>
            <input type="email" name="email" id="email" class="form-control" required
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>
        <div class="mb-4">
            <label class="form-label" for="password">Mật khẩu:</label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>
        <button class="btn btn-primary w-100">Đăng nhập</button>
    </form>

    <div class="form-footer">
        <p class="mt-3">Chưa có tài khoản? <a href="register.php">Đăng ký ngay</a></p>
    </div>
</div>

<?php include 'user/footer.php'; ?>
