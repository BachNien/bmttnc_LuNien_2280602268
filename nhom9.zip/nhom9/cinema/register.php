<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (!$name || !$email || !$password || !$confirm) {
        $errors[] = 'Vui lòng nhập đầy đủ tất cả các trường.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email không hợp lệ.';
    } elseif ($password !== $confirm) {
        $errors[] = 'Mật khẩu nhập lại không khớp.';
    } else {
        // Kiểm tra trùng email
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'Email đã được sử dụng.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$name, $email, $hashed]);
            header("Location: login.php");
            exit;
        }
    }
}
?>

<?php include 'user/header.php'; ?>
<div class="container mt-5" style="max-width: 500px">
    <h2 class="text-center">📝 Đăng ký tài khoản</h2>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <?= implode('<br>', $errors) ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label>Họ và tên:</label>
            <input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label>Email:</label>
            <input type="email" name="email" class="form-control" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label>Mật khẩu:</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Nhập lại mật khẩu:</label>
            <input type="password" name="confirm" class="form-control" required>
        </div>
        <button class="btn btn-success w-100">Đăng ký</button>
    </form>

    <div class="text-center mt-3">
        <a href="login.php">Đã có tài khoản? Đăng nhập</a>
    </div>
</div>
<?php include 'user/footer.php'; ?>
